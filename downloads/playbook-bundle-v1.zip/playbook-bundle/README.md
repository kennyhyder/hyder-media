# The Modern AI-Discoverable SaaS Launch Playbook

Thanks for buying. Here's what's in this bundle.

## Files

| File | What it is | How to use |
|---|---|---|
| `playbook-v1.pdf` | The full 100+ page playbook, polished + printable | Read end-to-end on first use; reference specific sections during your build |
| `playbook-source.md` | Markdown source of the playbook | Grep it, fork it, embed it in your team wiki |
| `SKILL.md` | Claude skill manifest | Drop into `~/.claude/skills/saas-launch-playbook/` to invoke via `/saas-launch-playbook` |
| `templates/llms.txt` | Fill-in-the-blanks llms.txt template | Replace placeholders with your project info; save to your repo's `/public/llms.txt` |
| `templates/webApplicationLd.ts` | Typed TypeScript JSON-LD generator | Drop into `lib/seo.ts`, customize, mount in your root layout |
| `templates/csp-reference.md` | Reference CSP for Stripe + GA4 + Supabase | Use as starting point for your `next.config.ts` headers |
| `publish/build-pdf.py` | The script that built this PDF (Python + Chrome headless) | If you fork the playbook, re-export your version with this |
| `publish/playbook.css` | Branded print CSS | Used by build-pdf.py; edit if you want different fonts/colors |
| `publish/pdf.md` + `publish/website.md` | Distribution recipes | If you want to republish or excerpt the playbook |

## Quick wins (do these in the first hour)

1. **Read the foreword + the 5-layer model (§1)**. 10 minutes. Tells you the conceptual frame.
2. **Run through §0 pre-flight checklist**. 30 minutes. Confirms your foundation is set up correctly.
3. **Drop `SKILL.md` into your Claude skills dir** if you use Claude Code. Then invoke `/saas-launch-playbook` on your current project.

## Install the Claude skill

```bash
mkdir -p ~/.claude/skills/saas-launch-playbook
cp SKILL.md ~/.claude/skills/saas-launch-playbook/
```

Then in any project, ask Claude `/saas-launch-playbook` and it'll audit your current state + apply patterns from this playbook.

## License

Personal use within one organization (your company / startup). Not for resale or redistribution.

For team licenses (5+ seats) or commercial distribution rights, email kenny@hyder.me.

## 12 months of free updates

Updates ship quarterly when new patterns are documented. You'll get an email at the address you bought with. If you change email, reply to your purchase receipt with the new one.

## Refunds

7-day money-back guarantee if the playbook doesn't fit your project. Forward your Lemon Squeezy receipt to kenny@hyder.me and the refund processes within 24 hours.

## Feedback

Found a bug? Disagree with a recommendation? Got a defensive pattern of your own to contribute?

Email kenny@hyder.me. I read every reply.

If your contribution lands in v2, you get acknowledged in the credits + a 50% discount on the v2 upgrade.

---

*Kenny Hyder · Hyder Media · 2026*
